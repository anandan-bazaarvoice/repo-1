<?php

$_SERVER['SERVER_NAME'] = "localhost";
$_SERVER['SERVER_PORT'] = "80";
$_SERVER['REQUEST_URI'] = "index.php";

